<?php

    require('../admin/inc/db-config.php');
    require('../admin/inc/essentials.php');

    if(isset($_POST['send']))
    {
          $data = filteration($_POST);
          $query = "INSERT INTO `review` (`name`, `message`) VALUES (?,?)";
           $values =[$data['name'],$data['message']];
  
           if(insert($query,$values,'ss')){
              echo 1;
           }
           else{
              echo 'ins_failed';
           }
    }
    ?>