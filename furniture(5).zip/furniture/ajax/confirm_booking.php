<?php

    require('../admin/inc/db-config.php');
    require('../admin/inc/essentials.php');

    date_default_timezone_set("Asia/Kolkata");
     
    if(isset($_POST['check_availability']))
    {
        $frm_data = filteration($_POST);
        $status = "";
        $result = "";
        
        $today_date = new DateTime(date("Y-m-d"));
        $rentin_date = new DateTime($frm_data['rent_in']);
        $rentout_date = new DateTime($frm_data['rent_out']);
        $maxDate = clone $rentin_date;
        $maxDate->modify('+30 days');

        if($rentin_date == $rentout_date)
        {
            $status = 'rent_in_out_equal';
            $result = json_encode(["status"=>$status]);
        }
        else if($rentout_date < $rentin_date)
        {
            $status = 'rent_out_earlier';
            $result = json_encode(["status"=>$status]);
        }
        else if ($rentout_date > $maxDate) {
            $status = 'rent_out_more';
            $result = json_encode(["status" => $status]);
        }
        
        else if($rentin_date < $today_date)
        {
            $status = 'rent_in_earlier';
            $result = json_encode(["status"=>$status]);
        }
      
        if($status!=''){
            echo $result;
        }
        
        else{
             session_start();
             $_SESSION['product'];
         
              $tb_query = "SELECT COUNT(*) AS `total_bookings` FROM `booking_order`
            WHERE booking_status=? AND product_id=?
            AND rent_out > ? AND rent_in < ?";

            $values = ['1',$_SESSION['product']['id'],$frm_data['rent_in'],$frm_data['rent_out']];
            $tb_fetch = mysqli_fetch_assoc(select($tb_query,$values,'iiss'));

            $rq_result = select("SELECT `quantity` FROM `products` WHERE `id`=?",[$_SESSION['product']['id']],'i');
            $rq_fetch = mysqli_fetch_assoc($rq_result);

           if(($rq_fetch['quantity']-$tb_fetch['total_bookings'])==0){
                $status = 'unavailable';
                $result = json_encode(['status'=>$status]);
                echo $result;
                exit;
             }    
 
            $count_days = date_diff($rentin_date,$rentout_date)->days;
            $payment = $_SESSION['product']['price'] * $count_days;
            
            $_SESSION['product']['payment'] = $payment;
            $_SESSION['product']['available'] = true;

            $result = json_encode(["status"=>'available',"days"=>$count_days,"payment"=>$payment]);
            echo $result;

           }


    }
 ?>