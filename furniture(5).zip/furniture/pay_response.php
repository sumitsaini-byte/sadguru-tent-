
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
 
<?php require('inc/links.php'); ?>
<title>CONFIRM BOOKING</title>


</head>
<body class="bg-light">
   
    <?php require('inc/header.php'); ?>

    <br>
    <div class="col-20 my-5 px-5">

    <div class="bg-white p-3 p-md-4 rounded shadow-sm">

    <h2 class="fw-bold h-font">booked successfully</h2>
    <a class="btn btn-sm btn-outline-dark shadow-none " href="index.php">Go Back To Home</a>
</div>
</div>

   

<?php require('inc/footer.php'); ?>

 

</body>
</html>